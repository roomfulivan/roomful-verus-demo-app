export const LOGIN_FAIL = 'loginfailed'
export const LOGIN_REGISTER = 'loginregister'
export const LOGIN_REGISTERED = 'loginregistered'
export const SIGNATURE_OK = 'signatureok'
export const SIGNATURE_INVALID = 'signatureinvalid'
export const LOADING_DISPLAY = "LOADING_DISPLAY"